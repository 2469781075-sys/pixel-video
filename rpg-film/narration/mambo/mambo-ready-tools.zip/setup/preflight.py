"""Check actual files and CPU capability without claiming synthesis readiness."""
import json
from pathlib import Path
import sys
import torch

ROOT = Path('/workspace/tts-tools')
required = [
    'mambo-models/manbo-e10.ckpt', 'mambo-models/manbo_e8_s168.pth',
    'mambo-models/refer.wav',
    'base-models/chinese-roberta-wwm-ext-large/config.json',
    'base-models/chinese-hubert-base/config.json',
    'base-models/G2PWModel/g2pW.onnx',
    'base-models/G2PWModel/config.py',
    'base-models/G2PWModel/POLYPHONIC_CHARS.txt',
    'base-models/G2PWModel/MONOPHONIC_CHARS.txt',
    'base-models/G2PWModel/char_bopomofo_dict.json',
    'base-models/G2PWModel/bopomofo_to_pinyin_wo_tune_dict.json',
]
missing = [p for p in required if not (ROOT / p).is_file()]
tokenizer = ROOT / 'base-models/chinese-roberta-wwm-ext-large'
if not any((tokenizer / p).is_file() for p in ('vocab.txt', 'tokenizer.json')):
    missing.append('base-models/chinese-roberta-wwm-ext-large/<tokenizer>')
for folder in ('chinese-roberta-wwm-ext-large', 'chinese-hubert-base'):
    root = ROOT / 'base-models' / folder
    if not any(root.glob('*.bin')) and not any(root.glob('*.safetensors')):
        missing.append('base-models/' + folder + '/<model weights>')
torch.set_num_threads(4)
x = torch.arange(16, dtype=torch.float32).reshape(4, 4)
assert torch.isfinite(x @ x).all()
print(json.dumps({'torch': torch.__version__, 'device': 'cpu',
                  'cpu_computation': 'passed', 'missing_files': missing}, indent=2))
sys.exit(2 if missing else 0)
