#!/usr/bin/env bash
set -euo pipefail
tts_root=/workspace/tts-tools
export HF_HOME="$tts_root/hf-cache"
export XDG_CACHE_HOME="$tts_root/cache"
export NLTK_DATA="$tts_root/nltk-data"
export bert_path="$tts_root/base-models/chinese-roberta-wwm-ext-large"
export OMP_NUM_THREADS=4
export MKL_NUM_THREADS=4
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
"$tts_root/mambo-venv/bin/python" "$tts_root/setup/preflight.py"
cd "$tts_root/GPT-SoVITS"
exec "$tts_root/mambo-venv/bin/python" api.py \
  -a 127.0.0.1 -p 9880 -d cpu -fp -sm close -mt wav \
  -s "$tts_root/mambo-models/manbo_e8_s168.pth" \
  -g "$tts_root/mambo-models/manbo-e10.ckpt" \
  -dr "$tts_root/mambo-models/refer.wav" \
  -dt '大家好，欢迎来到我的频道，今天给大家分享一个有趣的内容' \
  -dl all_zh \
  -hb "$tts_root/base-models/chinese-hubert-base" \
  -b "$tts_root/base-models/chinese-roberta-wwm-ext-large"
