"""Generate one WAV per original sentence, then derive exact sentence timings."""
import argparse
import io
import json
from pathlib import Path
import sys
import time
import urllib.error
import urllib.request
import wave


def wav_data(data):
    with wave.open(io.BytesIO(data), 'rb') as w:
        params = (w.getnchannels(), w.getsampwidth(), w.getframerate())
        if w.getcomptype() != 'NONE' or w.getnframes() == 0:
            raise ValueError('Expected a nonempty PCM WAV')
        frames = w.readframes(w.getnframes())
        if len(frames) != w.getnframes() * params[0] * params[1]:
            raise ValueError('Truncated WAV')
        return params, frames, w.getnframes()


def stamp(seconds):
    ms = round(seconds * 1000)
    return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--script', type=Path, default=Path('/workspace/pixel-video/rpg-film/narration/sentences.json'))
    p.add_argument('--original', type=Path, default=Path('/workspace/pixel-video/rpg-film/narration/original.txt'))
    p.add_argument('--output', type=Path, default=Path('/workspace/tts-tools/narration-output'))
    p.add_argument('--api-url', default='http://127.0.0.1:9880')
    p.add_argument('--limit', type=int, default=0)
    p.add_argument('--speed', type=float, default=1.0)
    args = p.parse_args()
    if not 0.1 <= args.speed <= 3 or args.limit < 0:
        p.error('speed must be 0.1–3.0 and limit must be nonnegative')
    script = json.loads(args.script.read_text(encoding='utf-8'))
    lines = script['sentences']
    strip = lambda s: ''.join(s.split())
    if strip(''.join(s['text'] for s in lines)) != strip(args.original.read_text(encoding='utf-8')):
        raise ValueError('Sentence script does not exactly reconstruct the original text')
    if args.limit:
        lines = lines[:args.limit]
    if not lines:
        raise ValueError('No sentences to synthesize')
    args.output.mkdir(parents=True, exist_ok=True)
    cues, clips = [], []
    common = None
    position = 0
    request_start = time.monotonic()
    for line in lines:
        body = json.dumps({'text': line['text'], 'text_language': 'all_zh',
                           'speed': args.speed, 'cut_punc': '，。？！；：、…,.;?!'},
                          ensure_ascii=False).encode('utf-8')
        request = urllib.request.Request(args.api_url.rstrip('/') + '/', data=body,
                                          headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(request, timeout=1200) as response:
            data = response.read()
        params, frames, count = wav_data(data)
        if common is not None and params != common:
            raise ValueError('Engine changed WAV format between sentences')
        common = params
        name = f"{line['id']:03}.wav"
        tmp = args.output / (name + '.tmp')
        tmp.write_bytes(data)
        tmp.replace(args.output / name)
        rate = params[2]
        cues.append({**line, 'audio_file': name, 'start_seconds': position/rate,
                     'end_seconds': (position+count)/rate})
        clips.append(frames)
        position += count
        if len(cues) < len(lines):
            gap = round(rate * 0.25)
            # PCM WAV from GPT-SoVITS is 16-bit; retain general 8-bit support.
            clips.append((b'\x80' if params[1] == 1 else b'\0') * gap * params[0] * params[1])
            position += gap
        print(f"{line['id']:03}: {count/rate:.2f}s", flush=True)
    with wave.open(str(args.output / 'narration.wav'), 'wb') as w:
        w.setnchannels(common[0]); w.setsampwidth(common[1]); w.setframerate(common[2])
        w.writeframes(b''.join(clips))
    manifest = {**script, 'timing_status': 'measured_from_sentence_audio',
                'complete_article': len(lines) == len(script['sentences']),
                'speed': args.speed, 'synthesis_seconds': time.monotonic()-request_start,
                'sentences': cues}
    (args.output/'timings.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    srt = '\n\n'.join(f"{i}\n{stamp(s['start_seconds'])} --> {stamp(s['end_seconds'])}\n{s['text']}"
                       for i,s in enumerate(cues,1)) + '\n'
    (args.output/'subtitles.srt').write_text(srt,encoding='utf-8')
    print(f'Written {len(cues)} sentences to {args.output}')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, urllib.error.URLError, wave.Error) as exc:
        print(f'Synthesis failed: {exc}', file=sys.stderr)
        sys.exit(1)
