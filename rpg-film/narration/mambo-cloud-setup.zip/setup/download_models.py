"""Fetch the Chinese inference assets needed by the supplied Mambo v2 voice."""
import json
import shutil
from pathlib import Path
from zipfile import ZipFile

from huggingface_hub import HfApi, hf_hub_download, snapshot_download

ROOT = Path('/workspace/tts-tools')
BASE = ROOT / 'base-models'
CACHE = ROOT / 'hf-cache'
BASE.mkdir(exist_ok=True)
api = HfApi()

# Resolve commits before downloading, so each group of files is consistent.
repo = 'lj1995/GPT-SoVITS'
revision = api.model_info(repo).sha
snapshot_download(
    repo_id=repo, revision=revision, cache_dir=str(CACHE), local_dir=str(BASE),
    allow_patterns=['chinese-roberta-wwm-ext-large/*', 'chinese-hubert-base/*'],
    max_workers=4,
)
g2pw_repo = 'XXXXRT/GPT-SoVITS-Pretrained'
g2pw_revision = api.model_info(g2pw_repo).sha
archive = hf_hub_download(
    repo_id=g2pw_repo, revision=g2pw_revision, filename='G2PWModel.zip',
    cache_dir=str(CACHE),
)
target = BASE / 'G2PWModel'
with ZipFile(archive) as z:
    if z.testzip() is not None:
        raise RuntimeError('G2PW ZIP integrity check failed')
    for item in z.infolist():
        parts = Path(item.filename).parts
        if parts and parts[0] in ('G2PWModel', 'G2PWModel_1.1'):
            parts = parts[1:]
        if not parts:
            continue
        dest = target.joinpath(*parts)
        if not dest.resolve().is_relative_to(target.resolve()):
            raise RuntimeError('Unsafe path in model archive')
        if item.is_dir():
            dest.mkdir(parents=True, exist_ok=True)
        else:
            dest.parent.mkdir(parents=True, exist_ok=True)
            with z.open(item) as src, dest.open('wb') as dst:
                shutil.copyfileobj(src, dst)

link = ROOT / 'GPT-SoVITS/GPT_SoVITS/text/G2PWModel'
if not link.exists() and not link.is_symlink():
    link.symlink_to(target, target_is_directory=True)
elif link.resolve() != target.resolve():
    raise RuntimeError('Existing G2PWModel path retained; inspect before replacing')
(BASE / 'sources.json').write_text(json.dumps({
    'chinese_models': {'repository': repo, 'revision': revision},
    'g2pw': {'repository': g2pw_repo, 'revision': g2pw_revision},
}, indent=2) + '\n')
print('Chinese base models downloaded; run preflight.py next.')
