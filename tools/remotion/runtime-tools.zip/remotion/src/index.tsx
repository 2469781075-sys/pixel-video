import React from 'react';
import {
  AbsoluteFill,
  Composition,
  Img,
  registerRoot,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {Audio} from '@remotion/media';

const PixelRuntimeCheck: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const drop = Math.floor((frame % fps) / 3);

  return (
    <AbsoluteFill style={{backgroundColor: '#243142'}}>
      <Img
        src={staticFile('classroom.png')}
        style={{width: '100%', height: '100%', imageRendering: 'pixelated'}}
      />
      <div
        style={{
          position: 'absolute',
          left: 196,
          top: 128 + drop * 4,
          width: 4,
          height: 12,
          backgroundColor: '#b7e4fa',
          opacity: 0.6,
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: 120,
          right: 120,
          bottom: 40,
          padding: '22px 32px',
          color: '#ffffff',
          backgroundColor: 'rgba(20, 28, 43, 0.86)',
          border: '4px solid #dde9ee',
          fontFamily: 'Noto Sans CJK SC, sans-serif',
          fontSize: 52,
          lineHeight: 1.4,
          textAlign: 'center',
        }}
      >
        不知道大家的中学生活是怎么样的？
      </div>
      <Audio src={staticFile('mambo-first-line.mp3')} volume={0.7} premountFor={fps} />
    </AbsoluteFill>
  );
};

const Root: React.FC = () => (
  <Composition
    id="PixelRuntimeCheck"
    component={PixelRuntimeCheck}
    width={1920}
    height={1080}
    fps={24}
    durationInFrames={120}
  />
);

registerRoot(Root);
