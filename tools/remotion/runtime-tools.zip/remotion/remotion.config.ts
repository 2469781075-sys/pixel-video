import {Config} from '@remotion/cli/config';

Config.setBrowserExecutable('/usr/bin/chromium');
Config.setConcurrency(2);
Config.setCodec('h264');
Config.setPixelFormat('yuv420p');
Config.setColorSpace('bt709');
