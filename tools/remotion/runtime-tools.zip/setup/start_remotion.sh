#!/usr/bin/env bash
set -euo pipefail
engine_root=/workspace/video-tools/remotion
test -x "$engine_root/node_modules/.bin/remotion"
if python3 - <<'PY'
import urllib.request
try:
    with urllib.request.urlopen('http://127.0.0.1:3001', timeout=2) as r:
        text = r.read().decode()
    if 'remotion' not in text.lower():
        print('Port 3001 belongs to another service; leave it untouched.')
        raise SystemExit(2)
except (urllib.error.URLError, TimeoutError):
    raise SystemExit(1)
print('Existing Remotion Studio responds; reuse it after checking its composition and bundle.')
PY
then
  exit 0
else
  studio_status=$?
  if [ "$studio_status" -ne 1 ]; then
    exit "$studio_status"
  fi
fi
cd "$engine_root"
exec "$engine_root/node_modules/.bin/remotion" studio src/index.tsx --no-open --port=3001
