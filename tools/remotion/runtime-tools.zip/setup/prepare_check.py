"""Prepare runtime-check assets from the retained, approved project files."""
from pathlib import Path
import shutil
from PIL import Image

root = Path('/workspace/video-tools/remotion')
repo = Path('/workspace/pixel-video')
public = root / 'public'
public.mkdir(exist_ok=True)
(root / 'output').mkdir(exist_ok=True)
with Image.open(repo / 'rpg-film/full-film/assets/classroom-wide.png') as img:
    img.convert('RGB').resize((480, 270), Image.Resampling.NEAREST).save(public / 'classroom.png')
shutil.copyfile(repo / 'rpg-film/narration/mambo/first-line.mp3', public / 'mambo-first-line.mp3')
print('Runtime check references ready: approved classroom plate and existing Mambo first sentence.')
