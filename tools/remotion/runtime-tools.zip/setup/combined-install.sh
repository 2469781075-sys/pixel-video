#!/usr/bin/env bash
set -euo pipefail
tts_root=/workspace/tts-tools
mkdir -p "$tts_root/setup"
export UV_CACHE_DIR="$tts_root/.uv-cache"
export HF_HOME="$tts_root/hf-cache"
export XDG_CACHE_HOME="$tts_root/cache"
export CC=gcc
export CXX=g++
export CMAKE_BUILD_PARALLEL_LEVEL=4
if [ ! -d "$tts_root/GPT-SoVITS/.git" ]; then
  git clone --depth 1 --branch 20250606v2pro https://github.com/RVC-Boss/GPT-SoVITS.git "$tts_root/GPT-SoVITS"
fi
test "$(git -C "$tts_root/GPT-SoVITS" rev-parse HEAD)" = d7c2210da8c013e81a94bfc7b811a477c99fd506
if [ ! -f "$tts_root/MamboTTS-v1.2.1-full.zip" ]; then
  curl --fail --location --retry 3 --connect-timeout 20 \
    https://github.com/Tsukimisaka/MamboTTS/releases/download/v1.2.1/MamboTTS-v1.2.1-full.zip \
    --output "$tts_root/MamboTTS-v1.2.1-full.zip"
fi
cd "$tts_root"
printf '%s\n' '8c4e67356a34a347628deeb99680db16ab5daf8f3321cf6e4cd97ebbcdd8bbe3  MamboTTS-v1.2.1-full.zip' | sha256sum --check
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile
import hashlib
root=Path('/workspace/tts-tools')
target=root/'mambo-models'
target.mkdir(exist_ok=True)
with ZipFile(root/'MamboTTS-v1.2.1-full.zip') as z:
    if z.testzip() is not None: raise RuntimeError('Corrupt release ZIP')
    for name in ('manbo-e10.ckpt','manbo_e8_s168.pth','refer.wav'):
        data=z.read('MamboTTS-v1.2.1-full/models/'+name)
        out=target/name
        if out.exists() and hashlib.sha256(out.read_bytes()).digest()!=hashlib.sha256(data).digest():
            raise RuntimeError('Existing model retained; inspect '+str(out))
        if not out.exists(): out.write_bytes(data)
PY
if [ ! -x "$tts_root/mambo-venv/bin/python" ]; then
  uv venv --python python3 "$tts_root/mambo-venv"
fi
uv pip install --python "$tts_root/mambo-venv/bin/python" \
  torch==2.5.1+cpu torchaudio==2.5.1+cpu --index-url https://download.pytorch.org/whl/cpu
uv pip install --python "$tts_root/mambo-venv/bin/python" \
  -r "$tts_root/GPT-SoVITS/requirements.txt" -c "$tts_root/setup/mambo-environment.txt"
uv pip check --python "$tts_root/mambo-venv/bin/python"
if [ ! -x "$tts_root/pixel-video-venv/bin/python" ]; then
  uv venv --python python3 "$tts_root/pixel-video-venv"
fi
uv pip install --python "$tts_root/pixel-video-venv/bin/python" \
  -r /workspace/pixel-video/rpg-film/part-01/requirements.txt
if [ "${1:-}" != --prepare-only ]; then
  if "$tts_root/mambo-venv/bin/python" "$tts_root/setup/preflight.py"; then
    echo 'Existing base models retained; no model download required.'
  else
    "$tts_root/mambo-venv/bin/python" "$tts_root/setup/download_models.py"
    "$tts_root/mambo-venv/bin/python" "$tts_root/setup/preflight.py"
  fi
else
  echo 'CPU dependencies and voice assets prepared. Base model download and real speech validation remain required.'
fi

# Keep the installed optional Remotion renderer reproducible.
bash /workspace/video-tools/setup/install_remotion.sh

