#!/usr/bin/env bash
set -euo pipefail
render_root=/workspace/video-tools
engine_root="$render_root/remotion"
pixel_python=/workspace/tts-tools/pixel-video-venv/bin/python
command -v node >/dev/null
command -v npm >/dev/null
command -v ffmpeg >/dev/null
command -v ffprobe >/dev/null
test -x /usr/bin/chromium
test -f "$engine_root/package-lock.json"
test -f "$engine_root/src/index.tsx"
test -f "$engine_root/tsconfig.json"
test -x "$pixel_python"
mkdir -p "$render_root/npm-cache"
cd "$engine_root"
node -e 'if (Number(process.versions.node.split(".")[0]) < 22) throw new Error("Node 22 or newer required")'
lock_fingerprint=$(sha256sum package-lock.json | cut -d ' ' -f 1)
if [ ! -x node_modules/.bin/remotion ] || [ ! -f .installed-lock.sha256 ] || [ "$(cat .installed-lock.sha256)" != "$lock_fingerprint" ]; then
  npm --cache "$render_root/npm-cache" ci --ignore-scripts --no-fund --no-audit
  printf '%s\n' "$lock_fingerprint" > .installed-lock.sha256
fi
npm --cache "$render_root/npm-cache" exec -- remotion versions
"$pixel_python" "$render_root/setup/prepare_check.py"
echo 'Remotion runtime and check assets prepared. Run render-check and verify_runtime.py to validate actual output.'
