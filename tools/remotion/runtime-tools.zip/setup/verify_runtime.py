"""Verify the actual Remotion output, decoded audio, fixed plate, and Studio assets."""
from pathlib import Path
import json
import re
import subprocess
import urllib.request
import numpy as np

root = Path('/workspace/video-tools/remotion')
video = root / 'output/runtime-check.mp4'

def run(args):
    return subprocess.run(args, check=True, capture_output=True).stdout

info = json.loads(run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(video)]))
v = next(s for s in info['streams'] if s['codec_type'] == 'video')
a = next(s for s in info['streams'] if s['codec_type'] == 'audio')
assert (v['width'], v['height'], v['r_frame_rate'], v['nb_frames']) == (1920, 1080, '24/1', '120')
assert v['codec_name'] == 'h264' and v['pix_fmt'] == 'yuv420p' and v['color_space'] == 'bt709'
assert a['codec_name'] == 'aac' and a['channels'] == 2 and a['sample_rate'] == '48000'
assert abs(float(info['format']['duration']) - 5) < .03
run(['ffmpeg', '-v', 'error', '-threads', '2', '-i', str(video), '-map', '0:v:0', '-map', '0:a:0', '-f', 'null', '-'])

def mono(path):
    return np.frombuffer(run(['ffmpeg', '-v', 'error', '-i', str(path), '-ar', '48000', '-ac', '1', '-f', 'f32le', '-']), dtype='<f4')

speech = mono(root / 'public/mambo-first-line.mp3')
mixed = mono(video)
# MP3/AAC decoders can have different priming offsets. Measure the alignment and
# require it to be less than one video frame, rather than assuming zero samples.
size = 1
while size < len(speech) + len(mixed) - 1:
    size *= 2
xcorr = np.fft.irfft(np.fft.rfft(mixed, size) * np.conj(np.fft.rfft(speech, size)), size)
indices = np.r_[np.arange(48001), np.arange(size - 48000, size)]
peak = int(indices[np.argmax(xcorr[indices])])
lag = peak if peak < size // 2 else peak - size
assert abs(lag) <= 48000 / 24, f'Audio shifted by more than one video frame: {lag / 48:.3f} ms'
start_s, start_m = max(0, -lag), max(0, lag)
n = min(len(speech) - start_s, len(mixed) - start_m, 120000)
reference = speech[start_s:start_s + n].astype(np.float64)
actual = mixed[start_m:start_m + n].astype(np.float64)
correlation = float(np.corrcoef(reference, actual)[0, 1])
assert correlation > .95, correlation
gain = float(np.dot(reference, actual) / np.dot(reference, reference))
assert .9 < gain < 1.1, gain
assert np.max(np.abs(mixed)) < .96
rms = float(np.sqrt(np.mean(actual ** 2)))
assert rms > .008

frames = []
for t in [0, .25]:
    data = run(['ffmpeg', '-v', 'error', '-ss', str(t), '-i', str(video), '-frames:v', '1', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'])
    frames.append(np.frombuffer(data, dtype=np.uint8).reshape(1080, 1920, 3))
delta = np.abs(frames[0].astype(np.int16) - frames[1].astype(np.int16))
outside = np.ones((1080, 1920), dtype=bool)
outside[110:200, 180:220] = False
background_delta = float(delta[outside].mean())
motion_delta = float(delta[120:175, 192:204].mean())
assert background_delta < 1.0, background_delta
assert motion_delta > .1, motion_delta

with urllib.request.urlopen('http://127.0.0.1:3001', timeout=20) as r:
    html = r.read().decode()
    assert r.status == 200 and 'remotion' in html.lower()
scripts = re.findall(r'<script[^>]*src=["\x27]([^"\x27]+)', html)
assert '/bundle.js' in scripts
with urllib.request.urlopen('http://127.0.0.1:3001/bundle.js', timeout=30) as r:
    bundle = r.read()
    assert r.status == 200 and b'PixelRuntimeCheck' in bundle

result = {
    'status': 'passed',
    'remotion': '4.0.534',
    'video': {'path': str(video), 'duration_seconds': float(info['format']['duration']), 'dimensions': [1920, 1080], 'fps': 24, 'frames': 120, 'codec': 'h264', 'pixel_format': v['pix_fmt'], 'color_space': v['color_space'], 'file_bytes': video.stat().st_size},
    'audio': {'codec': 'aac', 'channels': 2, 'sample_rate': 48000, 'mambo_source_correlation': round(correlation, 6), 'decoder_alignment_ms': round(lag / 48, 3), 'aligned_source_gain': round(gain, 6), 'speech_rms': round(rms, 6), 'peak_below_clipping': True},
    'motion': {'fixed_plate_mean_absolute_difference': round(background_delta, 6), 'local_motion_mean_absolute_difference': round(motion_delta, 6)},
    'full_decode': 'passed',
    'studio_http_and_composition_bundle': 'passed',
    'interactive_browser_ui': 'not_exercised',
    'separate_new_task_restoration': 'not_tested',
}
(root / 'output/verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
